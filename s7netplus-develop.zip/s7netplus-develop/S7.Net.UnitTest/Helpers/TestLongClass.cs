﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace S7.UnitTest.Helpers
{ 
    /// <summary>
    /// This is a class that contains more than 200 bytes and that needs 2 plc requests to complete a read/write cycle
    /// </summary>
    class TestLongClass
    {
        public short IntVariable0 { get; set; }
        public short IntVariable1 { get; set; }
        public short IntVariable2 { get; set; }
        public short IntVariable3 { get; set; }
        public short IntVariable4 { get; set; }
        public short IntVariable5 { get; set; }
        public short IntVariable6 { get; set; }
        public short IntVariable7 { get; set; }
        public short IntVariable8 { get; set; }
        public short IntVariable9 { get; set; }

        public short IntVariable10 { get; set; }
        public short IntVariable11 { get; set; }
        public short IntVariable12 { get; set; }
        public short IntVariable13 { get; set; }
        public short IntVariable14 { get; set; }
        public short IntVariable15 { get; set; }
        public short IntVariable16 { get; set; }
        public short IntVariable17 { get; set; }
        public short IntVariable18 { get; set; }
        public short IntVariable19 { get; set; }

        public short IntVariable20 { get; set; }
        public short IntVariable21 { get; set; }
        public short IntVariable22 { get; set; }
        public short IntVariable23 { get; set; }
        public short IntVariable24 { get; set; }
        public short IntVariable25 { get; set; }
        public short IntVariable26 { get; set; }
        public short IntVariable27 { get; set; }
        public short IntVariable28 { get; set; }
        public short IntVariable29 { get; set; }

        public short IntVariable30 { get; set; }
        public short IntVariable31 { get; set; }
        public short IntVariable32 { get; set; }
        public short IntVariable33 { get; set; }
        public short IntVariable34 { get; set; }
        public short IntVariable35 { get; set; }
        public short IntVariable36 { get; set; }
        public short IntVariable37 { get; set; }
        public short IntVariable38 { get; set; }
        public short IntVariable39 { get; set; }

        public short IntVariable40 { get; set; }
        public short IntVariable41 { get; set; }
        public short IntVariable42 { get; set; }
        public short IntVariable43 { get; set; }
        public short IntVariable44 { get; set; }
        public short IntVariable45 { get; set; }
        public short IntVariable46 { get; set; }
        public short IntVariable47 { get; set; }
        public short IntVariable48 { get; set; }
        public short IntVariable49 { get; set; }

        public short IntVariable50 { get; set; }
        public short IntVariable51 { get; set; }
        public short IntVariable52 { get; set; }
        public short IntVariable53 { get; set; }
        public short IntVariable54 { get; set; }
        public short IntVariable55 { get; set; }
        public short IntVariable56 { get; set; }
        public short IntVariable57 { get; set; }
        public short IntVariable58 { get; set; }
        public short IntVariable59 { get; set; }

        public short IntVariable60 { get; set; }
        public short IntVariable61 { get; set; }
        public short IntVariable62 { get; set; }
        public short IntVariable63 { get; set; }
        public short IntVariable64 { get; set; }
        public short IntVariable65 { get; set; }
        public short IntVariable66 { get; set; }
        public short IntVariable67 { get; set; }
        public short IntVariable68 { get; set; }
        public short IntVariable69 { get; set; }

        public short IntVariable70 { get; set; }
        public short IntVariable71 { get; set; }
        public short IntVariable72 { get; set; }
        public short IntVariable73 { get; set; }
        public short IntVariable74 { get; set; }
        public short IntVariable75 { get; set; }
        public short IntVariable76 { get; set; }
        public short IntVariable77 { get; set; }
        public short IntVariable78 { get; set; }
        public short IntVariable79 { get; set; }

        public short IntVariable80 { get; set; }
        public short IntVariable81 { get; set; }
        public short IntVariable82 { get; set; }
        public short IntVariable83 { get; set; }
        public short IntVariable84 { get; set; }
        public short IntVariable85 { get; set; }
        public short IntVariable86 { get; set; }
        public short IntVariable87 { get; set; }
        public short IntVariable88 { get; set; }
        public short IntVariable89 { get; set; }

        public short IntVariable90 { get; set; }
        public short IntVariable91 { get; set; }
        public short IntVariable92 { get; set; }
        public short IntVariable93 { get; set; }
        public short IntVariable94 { get; set; }
        public short IntVariable95 { get; set; }
        public short IntVariable96 { get; set; }
        public short IntVariable97 { get; set; }
        public short IntVariable98 { get; set; }
        public short IntVariable99 { get; set; }

        public short IntVariable100 { get; set; }
        public short IntVariable101 { get; set; }
        public short IntVariable102 { get; set; }
        public short IntVariable103 { get; set; }
        public short IntVariable104 { get; set; }
        public short IntVariable105 { get; set; }
        public short IntVariable106 { get; set; }
        public short IntVariable107 { get; set; }
        public short IntVariable108 { get; set; }
        public short IntVariable109 { get; set; }

        public short IntVariable110 { get; set; }
        public short IntVariable111 { get; set; }
        public short IntVariable112 { get; set; }
        public short IntVariable113 { get; set; }
        public short IntVariable114 { get; set; }
        public short IntVariable115 { get; set; }
        public short IntVariable116 { get; set; }
        public short IntVariable117 { get; set; }
        public short IntVariable118 { get; set; }
        public short IntVariable119 { get; set; }
    }
}
