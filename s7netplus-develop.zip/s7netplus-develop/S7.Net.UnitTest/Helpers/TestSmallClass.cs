﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace S7.UnitTest.Helpers
{
    class TestSmallClass
    {
        public bool Bool1 { get; set; }
    }
}
